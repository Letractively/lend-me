package com.lendme;

public enum LendingStatus {

		ONGOING, FINISHED, DENIED, CANCELLED;

}
