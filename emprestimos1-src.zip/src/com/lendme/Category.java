package com.lendme;

/**
 * @author THE LENDERS
 * Item categories.
 *
 */

public enum Category {
	
	FILME, LIVRO, JOGO;////MOVIE,BOOK,GAME;
	

}
